﻿//CSI3450 TEAM SORT AND DESTROY

using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SQL_UI_Maybe
{
    public partial class Form1 : Form
    {
        MySqlConnection connection = new MySqlConnection("SERVER=localhost;DATABASE=VideoGameDB;UID=root;PWD=root;");
        public Form1()
        {
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Username_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void guest_Click(object sender, EventArgs e)
        {
            Form Form2 = new Form2();
            this.Hide();
            Form2.Show();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlCommand command_one = new MySqlCommand("Select count(*) from Account where Account_Username = '"+textBox1.Text+ "' and Account_Password = '" + textBox2.Text + "';", connection);
            MySqlDataAdapter sda = new MySqlDataAdapter();
            connection.Open();
            sda.SelectCommand = command_one;
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (textBox1.Text == "admin" && textBox2.Text == "admin")
            {

            }
            else
            {
                if (dt.Rows[0][0].ToString() == "1")
                {
                    MessageBox.Show("Right Password");
                }
                else
                {
                    MessageBox.Show("Wrong Username or Password");
                }
                connection.Close();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form Form3 = new Form3();
            this.Hide();
            Form3.Show();

        }
    }
}
