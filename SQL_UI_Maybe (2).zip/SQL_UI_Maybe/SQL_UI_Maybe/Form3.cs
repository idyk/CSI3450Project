﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SQL_UI_Maybe
{
    public partial class Form3 : Form
    {
        MySqlConnection connection = new MySqlConnection("SERVER=localhost;DATABASE=VideoGameDB;UID=root;PWD=root;");
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form Form1 = new Form1();
            this.Hide();
            Form1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlCommand command_one = new MySqlCommand("Select count(*) from Account where Account_Username = '" + textBox1.Text + "';", connection);
            MySqlCommand command_t = new MySqlCommand("Select Account_ID from Account;", connection);
            MySqlDataAdapter sda = new MySqlDataAdapter();
            connection.Open();
            sda.SelectCommand = command_one;
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DataTable det = new DataTable();
            sda.SelectCommand = command_t;
            sda.Fill(det);
            if (dt.Rows[0][0].ToString() == "1")
            {
                MessageBox.Show("Sorry Username in use!");
                connection.Close();
            }
            else
            {
                if (textBox2.ToString() == textBox3.ToString())
                {
                    connection.Close();
                    MySqlCommand command_two = new MySqlCommand("Insert Into Account Values ('" + det.Rows.Count + "','" + textBox1.Text + "','" + textBox2.Text + "');", connection);
                    connection.Open();
                    command_two.ExecuteNonQuery();
                    MessageBox.Show("Congrats on Signing Up");
                    Form Form1 = new Form1();
                    this.Hide();
                    Form1.Show();
                }
                else 
                {
                    MessageBox.Show("Your Passwords Dont Match");
                }
            }

        }
    }
}
