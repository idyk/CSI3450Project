﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace SQL_UI_Maybe
{

    public partial class Form3 : Form
    {

        
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("SERVER=35.199.39.10;DATABASE=VideoGameDB;UID=root;PWD=root;AllowLoadLocalInfile=True");
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = true;
            openFileDialog.Filter = "csv files (*.csv)|*.csv";
            var filePath = string.Empty;
            var fileContent = string.Empty;
 

            if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                filePath = openFileDialog.FileName;
                
                label2.Text = filePath;
                MySqlDataAdapter da = new MySqlDataAdapter();
                var fileStream = openFileDialog.OpenFile();

                using (StreamReader reader = new StreamReader(fileStream))
                {
                    fileContent = reader.ReadToEnd();
                    
                }


   
                //Weird permissions thing makes it not work???
                MySqlCommand command = new MySqlCommand("LOAD DATA INFILE '" + filePath + "' INTO TABLE GameStatType FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 ROWS;", connection);
                
                connection.Open();
                command.ExecuteNonQuery();                      
                connection.Close();

                System.Diagnostics.Debug.WriteLine("The contents of " + filePath + " are:\n" + fileContent);
            }
            
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.Text == "INSERT INTO")
            {
                label5.Text = "A guide will be displayed here!";
                textBox1.Enabled = true;
                textBox2.Enabled = false;
            }

            if(listBox1.Text == "DELETE FROM")
            {
                label5.Text = "";
                textBox2.Enabled = true;
                textBox1.Enabled = false;
            }

            if(listBox1.Text == "UPDATE")
            {
                label5.Text = "";
                textBox2.Enabled = true;
                textBox1.Enabled = false;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.Text == "INSERT INTO")
            updateLabel5(listBox2.Text);

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                //INSERT INTO
                if (textBox1.Enabled == true && listBox1.Text == "INSERT INTO" && listBox2.Text != null) {
                    MySqlConnection connection = new MySqlConnection("SERVER=35.199.39.10;DATABASE=VideoGameDB;UID=root;PWD=root;");
                    MySqlCommand command = new MySqlCommand(listBox1.Text + " " + listBox2.Text + " VALUES(" + textBox1.Text + ");", connection);

                                                 

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }

                

            }
            catch(Exception exec)
            {
                System.Diagnostics.Debug.WriteLine(exec.Message);
                errorLabel.Text = exec.Message;
            }
        }


        private void updateLabel5(string hint)
        {

            if (hint == "GameStatType")
            {
                label5.Text = "GameStatType_ID INT, GameStatType_Name VARCHAR(30)";
            }
            else if(hint == "Game")
            {
                label5.Text = "Game_ID INT, Game_Title VARCHAR(30)";
            }
            else if (hint == "GameStat")
            {
                label5.Text = "Player_ID INT, Game_ID INT, GameStatType_ID INT, GameStat_Value INT";
            }
            else if(hint == "Gamemode")
            {
                label5.Text = "Gamemode_ID INT, Gamemode_Name VARCHAR(30)";
            }
            else if(hint == "Gametype")
            {
                label5.Text = "Gamemode_ID INT, Game_ID INT, Gametype_ExpectedTime INT";
            }
            else if (hint == "StatType")
            {
                label5.Text = "StatType_ID INT, StatType_Name VARCHAR(30)";
            }
            else if(hint == "Stat")
            {
                label5.Text = "Player_ID INT, GameType_Gamemode_ID INT, Gametype_Game_ID INT, StatType_ID INT, Stat_Value INT";
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void errorLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
